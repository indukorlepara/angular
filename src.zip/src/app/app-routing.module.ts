import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ItemListComponent } from './item-list/item-list.component';
import { ProductListComponent } from './product-list/product-list.component';


const routes: Routes = [
  { path: '', redirectTo: '/items', pathMatch: 'full' }, // Default route redirects to Item List
  { path: 'items', component: ItemListComponent }, // Route for item list
  { path: 'products', component: ProductListComponent }, 
  
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
