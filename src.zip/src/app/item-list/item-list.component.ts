import { Component, OnInit } from '@angular/core';
import { ItemService, Item } from '../item.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css'],
})
export class ItemListComponent implements OnInit {
  items: Item[] = [];
  selectedItem: Item | null = null;

  constructor(private itemService: ItemService) {}

  ngOnInit(): void {
    this.loadItems();
  }

  // Load all items
  loadItems(): void {
    this.itemService.getItems().subscribe((data) => {
      this.items = data;
    });
  }


  // // Create an item
  createItem(): void {
    const newItem: Item = { _id: '', name: 'New Item', description: 'Description' };
    this.itemService.createItem(newItem).subscribe(() => {
      this.loadItems();
    });
  }



  // Select an item for updating
  selectItem(item: Item): void {
    this.selectedItem = item;
  }

  // Update an item
  updateItem(): void {
    if (this.selectedItem) {
      console.log(this.selectedItem._id);
      console.log(this.selectedItem);

      this.itemService.updateItem(this.selectedItem._id, this.selectedItem).subscribe(() => {
        this.loadItems();
      });
    }
  }

  // Delete an item
  deleteItem(id: string): void {
    this.itemService.deleteItem(id).subscribe(() => {
      this.loadItems();
    });
  }
}

