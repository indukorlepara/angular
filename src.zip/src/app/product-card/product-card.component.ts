import { Component, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-card',
  template: `
    <div class="product-card">
      <h3>{{ product.name }}</h3>
      <p>{{ product.description }}</p>
      <button (click)="toggleDetails()">Toggle Details</button>
      <div *ngIf="showDetails">
        <p>Price: {{ product.price | currency }}</p>
        <p>Stock: {{ product.stock }}</p>
        <button (click)="updateProduct()">Update Product</button>
      </div>
    </div>
  `,
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent {
  @Input() product: any;
  showDetails: boolean = false;

  constructor(private http: HttpClient) {}

  toggleDetails() {
    this.showDetails = !this.showDetails;
  }

  updateProduct() {
    const updatedProduct = { ...this.product, stock: this.product.stock + 1 };  // Example update: increasing stock
    this.http.put(`http://localhost:3000/api/products/${this.product._id}`, updatedProduct)
      .subscribe((data) => {
        this.product = data;
        alert('Product updated successfully!');
      });
  }
}

