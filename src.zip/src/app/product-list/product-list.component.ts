import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductCardComponent } from '../product-card/product-card.component';


@Component({
  selector: 'app-product-list',
  template: `
    <div>
      <h2>Product List</h2>
      <app-product-card *ngFor="let product of products" [product]="product" #productCard></app-product-card>
      <button (click)="toggleAllProductDetails()">Toggle All Product Details</button>
    </div>
  `,
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  @ViewChildren('productCard') productCards!: QueryList<ProductCardComponent>;
  products = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchProducts();
  }

  fetchProducts() {
    this.http.get('http://localhost:3000/api/products')
      .subscribe((data: any) => {
        this.products = data;
      });
  }

  toggleAllProductDetails() {
    this.productCards.toArray().forEach(card => card.toggleDetails());
  }
}
